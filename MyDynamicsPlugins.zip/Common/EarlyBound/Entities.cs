namespace Common.EarlyBound
{
    // Early-bound entity classes generated via CrmSvcUtil go here.
}