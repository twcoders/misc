using Microsoft.Xrm.Sdk;
using System;

namespace Common.Helpers
{
    public static class CrmHelper
    {
        public static void Trace(ITracingService tracing, string message)
        {
            tracing?.Trace($"{DateTime.Now}: {message}");
        }
    }
}