using Microsoft.Xrm.Sdk;
using Common.Helpers;

namespace Plugin.AccountCreate
{
    public class AccountCreatePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            CrmHelper.Trace(tracing, "AccountCreatePlugin started.");

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity entity)
            {
                if (!entity.Contains("description"))
                {
                    entity["description"] = "Created via plugin";
                }
            }

            CrmHelper.Trace(tracing, "AccountCreatePlugin completed.");
        }
    }
}