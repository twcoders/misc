using Microsoft.Xrm.Sdk;
using Common.Helpers;

namespace Plugin.ContactUpdate
{
    public class ContactUpdatePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            CrmHelper.Trace(tracing, "ContactUpdatePlugin triggered.");
        }
    }
}