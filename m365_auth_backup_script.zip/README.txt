# Microsoft 365 MFA & Authentication Settings Backup Script

## Instructions:

1. Open PowerShell as Administrator.
2. Run the script: `.ackup_mfa_settings.ps1`
3. Log in when prompted with a Global Admin account.
4. The script will:
   - Export all domain info (including federation status)
   - Backup per-user MFA status
   - Dump all Conditional Access policies
   - Save to a timestamped folder

## Output:
- domains.csv
- FederationSettings_<domain>.txt
- user_mfa_status.csv
- conditional_access_policies.json

Modules installed:
- MSOnline
- Microsoft.Graph

**Note**: This is a read-only backup. No changes are made to your tenant.
