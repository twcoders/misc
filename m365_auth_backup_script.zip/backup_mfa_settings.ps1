# Backup MFA and Authentication Settings for Microsoft 365
# Required Modules: MSOnline, Microsoft.Graph

Install-Module MSOnline -Force -Scope CurrentUser
Install-Module Microsoft.Graph -Force -Scope CurrentUser

Connect-MsolService
Connect-MgGraph -Scopes "Policy.Read.All", "User.Read.All"

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$exportFolder = "M365_Backup_$timestamp"
New-Item -Path "." -Name $exportFolder -ItemType Directory -Force | Out-Null

# Export Domain Info
Write-Host "Exporting domain info..."
Get-MsolDomain | Export-Csv "$exportFolder\domains.csv" -NoTypeInformation

# Export Federation Settings
$domains = Get-MsolDomain | Where-Object {$_.Authentication -eq "Federated"}
foreach ($domain in $domains) {
    Get-MsolDomainFederationSettings -DomainName $domain.Name |
        Out-File "$exportFolder\FederationSettings_$($domain.Name).txt"
}

# Export User MFA Status
Write-Host "Exporting user MFA status..."
Get-MsolUser | Select-Object UserPrincipalName, StrongAuthenticationRequirements |
    Export-Csv "$exportFolder\user_mfa_status.csv" -NoTypeInformation

# Export Conditional Access Policies
Write-Host "Exporting Conditional Access Policies..."
Get-MgConditionalAccessPolicy | ConvertTo-Json -Depth 10 |
    Out-File "$exportFolder\conditional_access_policies.json"

Write-Host "`n✅ Backup complete! Files saved to: $exportFolder" -ForegroundColor Green
