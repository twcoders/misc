/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    table: ComponentFramework.PropertyTypes.StringProperty;
    idField: ComponentFramework.PropertyTypes.StringProperty;
    nameField: ComponentFramework.PropertyTypes.StringProperty;
    titleField: ComponentFramework.PropertyTypes.StringProperty;
    managerField: ComponentFramework.PropertyTypes.StringProperty;
    extraFields: ComponentFramework.PropertyTypes.StringProperty;
    extraLabels: ComponentFramework.PropertyTypes.StringProperty;
    visibleLevel: ComponentFramework.PropertyTypes.WholeNumberProperty;
    pan: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    zoom: ComponentFramework.PropertyTypes.TwoOptionsProperty;
}
export interface IOutputs {
}
