import { IInputs, IOutputs } from "./generated/ManifestTypes";

export class OrgChartControl implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private container!: HTMLDivElement;
    private notifyOutputChanged!: () => void;
    private context!: ComponentFramework.Context<IInputs>;
    private chartHost!: HTMLDivElement;
    private status!: HTMLDivElement;
    private ocInstance: any;

    private static libsLoaded = false;

    public async init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement) {
        this.context = context;
        this.notifyOutputChanged = notifyOutputChanged;
        this.container = container;

        const root = document.createElement('div');
        root.className = 'pcf-org-root';

        const status = document.createElement('div');
        status.className = 'pcf-org-status';
        status.textContent = 'Loading…';
        this.status = status;

        const host = document.createElement('div');
        host.className = 'pcf-org-chart';
        this.chartHost = host;

        root.appendChild(status);
        root.appendChild(host);
        container.appendChild(root);

        await this.ensureLibraries();
        await this.render();
    }

    public async updateView(context: ComponentFramework.Context<IInputs>): Promise<void> {
        this.context = context;
        await this.render();
    }

    public getOutputs(): IOutputs { return {}; }
    public destroy(): void {
        if (this.ocInstance && this.ocInstance.$chart) {
            try { this.ocInstance.$chart.remove(); } catch {}
        }
    }

    private async ensureLibraries(): Promise<void> {
        if (OrgChartControl.libsLoaded) return;
        await this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js");
        await this.loadStyles("https://cdnjs.cloudflare.com/ajax/libs/orgchart/5.0.0/css/jquery.orgchart.min.css");
        await this.loadScript("https://cdnjs.cloudflare.com/ajax/libs/orgchart/5.0.0/js/jquery.orgchart.min.js");
        OrgChartControl.libsLoaded = true;
    }

    private loadScript(src: string): Promise<void> {
        return new Promise((resolve, reject) => {
            const s = document.createElement('script');
            s.src = src; s.async = true; s.onload = () => resolve(); s.onerror = () => reject(new Error(`Failed to load ${src}`));
            document.head.appendChild(s);
        });
    }
    private loadStyles(href: string): Promise<void> {
        return new Promise((resolve, reject) => {
            const l = document.createElement('link');
            l.rel = 'stylesheet'; l.href = href; l.onload = () => resolve(); l.onerror = () => reject(new Error(`Failed to load ${href}`));
            document.head.appendChild(l);
        });
    }

    private setStatus(msg: string, isError = false) {
        if (!this.status) return;
        this.status.textContent = msg || '';
        this.status.style.color = isError ? '#b00020' : '#666';
    }

    private getConfig() {
        const p = this.context.parameters;
        const getStr = (name: keyof IInputs, d?: string) => (p[name]?.raw ?? d ?? '').toString();
        const getBool = (name: keyof IInputs, d?: boolean) => (p[name]?.raw as any) ?? d ?? false;
        const csv = (s: string) => s.split(',').map(x => x.trim()).filter(Boolean);
        const extraFields = csv(getStr('extraFields','')).slice(0,4);
        const extraLabels = csv(getStr('extraLabels','')).slice(0, extraFields.length);
        return {
            table: getStr('table','systemuser'),
            idField: getStr('idField','systemuserid'),
            nameField: getStr('nameField','fullname'),
            titleField: getStr('titleField','jobtitle'),
            managerField: getStr('managerField','parentsystemuserid'),
            visibleLevel: Number(getStr('visibleLevel','4')) || 4,
            pan: !!getBool('pan', true),
            zoom: !!getBool('zoom', true),
            extraFields,
            extraLabels
        };
    }

    private prettifyLabel(name?: string) {
        return (name || '').replace(/_/g, ' ').replace(/\s+/g,' ').trim().replace(/(^|\s)\S/g, s => s.toUpperCase());
    }

    private getDisplayValue(rec: any, logical: string) {
        const f1 = rec[`${logical}@OData.Community.Display.V1.FormattedValue`];
        if (f1) return f1;
        const altKey = `_${logical}_value`;
        const f2 = rec[`${altKey}@OData.Community.Display.V1.FormattedValue`];
        if (f2) return f2;
        if (rec.hasOwnProperty(logical)) return rec[logical];
        if (rec.hasOwnProperty(altKey)) return rec[altKey];
        return '';
    }

    private toNode(cfg: any, rec: any) {
        const id = (rec[cfg.idField] || '').toLowerCase();
        const name = rec[cfg.nameField] || '';
        const title = cfg.titleField ? (rec[cfg.titleField] || '') : '';
        const extras: Array<{label:string, value:string}> = [];
        (cfg.extraFields || []).forEach((fn: string, i: number) => {
            const label = (cfg.extraLabels && cfg.extraLabels[i]) || this.prettifyLabel(fn);
            const val = this.getDisplayValue(rec, fn);
            if (val !== undefined && val !== null && String(val).trim() !== '') {
                extras.push({ label, value: String(val) });
            }
        });
        return { id, name, title, extras };
    }

    private buildFetchXmlChildren(cfg: any, parentIds: string[]) {
        const attr = (n: string) => `<attribute name='${n}' />`;
        const values = parentIds.map(id => `<value>{${id}}</value>`).join('');
        return `
            <fetch version='1.0' no-lock='true'>
                <entity name='${cfg.table}'>
                    ${attr(cfg.idField)}
                    ${attr(cfg.nameField)}
                    ${cfg.titleField ? attr(cfg.titleField) : ''}
                    ${(cfg.extraFields || []).map(attr).join('')}
                    ${attr(cfg.managerField)}
                    <filter>
                        <condition attribute='${cfg.managerField}' operator='in'>
                            ${values}
                        </condition>
                    </filter>
                </entity>
            </fetch>`;
    }

    private async retrieveMultipleFetchXml(table: string, fetchXml: string) {
        const encoded = `?fetchXml=${encodeURIComponent(fetchXml)}`;
        const res = await this.context.webAPI.retrieveMultipleRecords(table, encoded);
        return (res as any).entities || (res as any).value || [];
    }

    private async retrieveRecord(table: string, id: string, select: string, expand?: string) {
        const qs: string[] = [];
        if (select) qs.push(`$select=${select}`);
        if (expand) qs.push(`$expand=${expand}`);
        const query = qs.length ? `?${qs.join('&')}` : '';
        return this.context.webAPI.retrieveRecord(table, id, query);
    }

    private async findRootId(cfg: any, startId: string) {
        const normalize = (s?: string) => (s || '').replace(/[{}]/g,'').toLowerCase();
        const seen = new Set<string>();
        let current = normalize(startId);
        for (let i=0; i<10; i++) {
            if (!current || seen.has(current)) return current;
            seen.add(current);
            const rec = await this.retrieveRecord(cfg.table, current, `${cfg.idField},${cfg.managerField}`, `${cfg.managerField}($select=${cfg.idField})`);
            const mgrObj = (rec as any)[cfg.managerField];
            if (mgrObj && mgrObj[cfg.idField]) {
                current = normalize(mgrObj[cfg.idField]);
            } else {
                const key = `_${cfg.managerField}_value`;
                const mgrId = (rec as any)[key] ? normalize((rec as any)[key]) : '';
                if (!mgrId) return current;
                current = mgrId;
            }
        }
        return current;
    }

    private async buildTree(cfg: any, rootId: string) {
        const select: string[] = [cfg.idField, cfg.nameField];
        if (cfg.titleField) select.push(cfg.titleField);
        if (cfg.extraFields && cfg.extraFields.length) select.push(...cfg.extraFields);
        const rootRec = await this.retrieveRecord(cfg.table, rootId, select.join(','));
        const root = this.toNode(cfg, rootRec);
        (root as any).children = [];

        const byId = new Map<string, any>([[root.id, root]]);
        let frontier = [root.id];
        let total = 1;
        const maxDepth = 10;

        for (let depth=1; depth<=maxDepth && frontier.length>0 && total<1000; depth++) {
            const fx = this.buildFetchXmlChildren(cfg, frontier);
            const children = await this.retrieveMultipleFetchXml(cfg.table, fx);
            if (!children.length) break;
            const next: string[] = [];
            for (const r of children) {
                if (total >= 1000) break;
                const node = this.toNode(cfg, r);
                if (!node.id) continue;
                if (!byId.has(node.id)) {
                    byId.set(node.id, node);
                    (node as any).children = [];
                    total++;
                }
                const parentId = ((r as any)[`_${cfg.managerField}_value`] || '').replace(/[{}]/g,'').toLowerCase();
                if (parentId && byId.has(parentId)) {
                    byId.get(parentId).children.push(node);
                }
                next.push(node.id);
            }
            frontier = next;
        }
        return root;
    }

    private async render() {
        this.setStatus('Loading…');
        try {
            const cfg = this.getConfig();
            const recordId = (this.context as any).mode?.contextInfo?.entityId || '';
            const startId = recordId && recordId.replace(/[{}]/g,'').toLowerCase();
            if (!startId) {
                this.setStatus('No current record id. Place this control on a form.');
                return;
            }
            const rootId = await this.findRootId(cfg, startId);
            const root = await this.buildTree(cfg, rootId);
            this.chartHost.innerHTML = '<div id="pcf-orgchart"></div>';
            const $ = (window as any).jQuery;
            const options: any = {
                data: root,
                nodeTitle: 'name',
                nodeId: 'id',
                pan: cfg.pan,
                zoom: cfg.zoom,
                visibleLevel: cfg.visibleLevel,
                nodeTemplate: (data: any) => {
                    const esc = (s: string) => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\"/g,'&quot;').replace(/'/g,'&#039;');
                    const pretty = (n: string) => this.prettifyLabel(n);
                    const lines: string[] = [];
                    if (cfg.titleField && data.title) lines.push(`<div class=\"kv\"><span class=\"k\">${pretty(cfg.titleField)}</span><span class=\"v\">${esc(String(data.title))}</span></div>`);
                    (data.extras || []).forEach((x: any) => lines.push(`<div class=\"kv\"><span class=\"k\">${esc(String(x.label))}</span><span class=\"v\">${esc(String(x.value))}</span></div>`));
                    return `
                        <div class=\"title\">${esc(String(data.name || ''))}</div>
                        <div class=\"content\">${lines.join('')}</div>
                    `;
                }
            };
            const oc = (window as any).jQuery('#pcf-orgchart').orgchart(options);
            this.ocInstance = oc;
            this.setStatus('');
        } catch (e: any) {
            console.error(e);
            this.setStatus(e?.message || 'Failed to render org chart', true);
        }
    }
}

