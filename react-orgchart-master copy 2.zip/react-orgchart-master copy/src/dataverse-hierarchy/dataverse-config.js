// Dataverse Hierarchy Configuration
// This module provides configuration and utilities for displaying hierarchical data
// from Dataverse entities with self-referencing lookup fields

export const DataverseHierarchyConfig = {
  // Common Dataverse entity configurations for hierarchy views
  entityConfigurations: {
    // Common scenario: Account hierarchy (Parent Account lookup)
    account: {
      entityName: 'account',
      primaryField: 'name',
      idField: 'accountid',
      parentField: 'parentaccountid',
      displayFields: ['name', 'accountnumber', 'telephone1'],
      titleField: 'name',
      subtitleField: 'accountnumber'
    },
    
    // Common scenario: Contact hierarchy (Manager lookup)
    contact: {
      entityName: 'contact',
      primaryField: 'fullname',
      idField: 'contactid',
      parentField: 'managerid',
      displayFields: ['fullname', 'jobtitle', 'emailaddress1'],
      titleField: 'fullname',
      subtitleField: 'jobtitle'
    },
    
    // Common scenario: System User hierarchy (Manager lookup)
    systemuser: {
      entityName: 'systemuser',
      primaryField: 'fullname',
      idField: 'systemuserid',
      parentField: 'managerid',
      displayFields: ['fullname', 'title', 'internalemailaddress'],
      titleField: 'fullname',
      subtitleField: 'title'
    },
    
    // Custom entity example - can be configured for any entity
    custom: {
      entityName: 'custom_entity',
      primaryField: 'custom_name',
      idField: 'custom_entityid',
      parentField: 'custom_parentid',
      displayFields: ['custom_name', 'custom_title'],
      titleField: 'custom_name',
      subtitleField: 'custom_title'
    }
  },

  // Default styling options for hierarchy nodes
  nodeStyles: {
    default: {
      backgroundColor: '#fff',
      borderColor: '#0078d4',
      textColor: '#323130',
      width: '200px',
      height: 'auto'
    },
    manager: {
      backgroundColor: '#0078d4',
      borderColor: '#106ebe',
      textColor: '#fff',
      width: '220px',
      height: 'auto'
    },
    inactive: {
      backgroundColor: '#f3f2f1',
      borderColor: '#edebe9',
      textColor: '#605e5c',
      width: '200px',
      height: 'auto'
    }
  },

  // Sample data transformation function
  transformDataverseData: (records, config) => {
    // Transform flat Dataverse records into hierarchical structure
    const recordsMap = new Map();
    const rootNodes = [];
    
    // First pass: Create all nodes
    records.forEach(record => {
      const node = {
        id: record[config.idField],
        name: record[config.titleField] || record[config.primaryField],
        title: record[config.subtitleField] || '',
        parentId: record[config.parentField],
        data: record, // Store original record for reference
        children: []
      };
      recordsMap.set(node.id, node);
    });
    
    // Second pass: Build hierarchy
    recordsMap.forEach(node => {
      if (node.parentId && recordsMap.has(node.parentId)) {
        const parent = recordsMap.get(node.parentId);
        parent.children.push(node);
      } else {
        rootNodes.push(node);
      }
    });
    
    // Return the first root node or create a virtual root if multiple roots
    if (rootNodes.length === 1) {
      return rootNodes[0];
    } else if (rootNodes.length > 1) {
      return {
        id: 'virtual-root',
        name: 'Organization',
        title: 'Root Level',
        children: rootNodes
      };
    } else {
      return {
        id: 'empty-root',
        name: 'No Data',
        title: 'No hierarchy data available',
        children: []
      };
    }
  }
};

// Power Platform integration helpers
export const PowerPlatformHelpers = {
  // Get current user context from Power Apps
  getCurrentUser: () => {
    if (window.parent && window.parent.Xrm) {
      return window.parent.Xrm.Utility.getGlobalContext().getUserId();
    }
    return null;
  },
  
  // Get organization context
  getOrgContext: () => {
    if (window.parent && window.parent.Xrm) {
      return window.parent.Xrm.Utility.getGlobalContext().getOrgUniqueName();
    }
    return null;
  },
  
  // Open record in Dataverse
  openRecord: (entityName, recordId) => {
    if (window.parent && window.parent.Xrm) {
      const pageInput = {
        pageType: "entityrecord",
        entityName: entityName,
        entityId: recordId
      };
      window.parent.Xrm.Navigation.navigateTo(pageInput);
    } else {
      // Fallback for standalone deployment
      console.log(`Open ${entityName} record: ${recordId}`);
    }
  },
  
  // Check if running in Power Apps context
  isPowerAppsContext: () => {
    return !!(window.parent && window.parent.Xrm);
  }
};

export default DataverseHierarchyConfig;
