import React, { useState, useEffect } from "react";
import OrganizationChart from "../components/ChartContainer";
import { DataverseHierarchyConfig, PowerPlatformHelpers } from "./dataverse-config";
import "./dataverse-hierarchy.css";

const DataverseHierarchyChart = ({ 
  entityConfig = DataverseHierarchyConfig.entityConfigurations.contact,
  hierarchyData = null,
  allowEdit = false,
  showToolbar = true,
  customNodeRenderer = null
}) => {
  const [chartData, setChartData] = useState(null);
  const [selectedNode, setSelectedNode] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  // Sample data for demonstration - replace with actual Dataverse data
  const sampleDataverseRecords = [
    {
      contactid: "user1",
      fullname: "John Smith",
      jobtitle: "Chief Executive Officer",
      emailaddress1: "john.smith@company.com",
      managerid: null
    },
    {
      contactid: "user2", 
      fullname: "Sarah Johnson",
      jobtitle: "Vice President of Sales",
      emailaddress1: "sarah.johnson@company.com",
      managerid: "user1"
    },
    {
      contactid: "user3",
      fullname: "Mike Davis",
      jobtitle: "Vice President of Engineering", 
      emailaddress1: "mike.davis@company.com",
      managerid: "user1"
    },
    {
      contactid: "user4",
      fullname: "Lisa Chen",
      jobtitle: "Sales Manager",
      emailaddress1: "lisa.chen@company.com", 
      managerid: "user2"
    },
    {
      contactid: "user5",
      fullname: "Tom Wilson",
      jobtitle: "Engineering Manager",
      emailaddress1: "tom.wilson@company.com",
      managerid: "user3"
    },
    {
      contactid: "user6",
      fullname: "Emma Brown",
      jobtitle: "Senior Developer",
      emailaddress1: "emma.brown@company.com",
      managerid: "user5"
    },
    {
      contactid: "user7",
      fullname: "David Lee",
      jobtitle: "Sales Representative",
      emailaddress1: "david.lee@company.com",
      managerid: "user4"
    }
  ];

  useEffect(() => {
    const loadHierarchyData = async () => {
      try {
        setIsLoading(true);
        
        // Use provided data or sample data
        const records = hierarchyData || sampleDataverseRecords;
        
        // Transform flat Dataverse records into hierarchical structure
        const transformedData = DataverseHierarchyConfig.transformDataverseData(records, entityConfig);
        
        setChartData(transformedData);
        setError(null);
      } catch (err) {
        console.error("Error loading hierarchy data:", err);
        setError("Failed to load hierarchy data");
      } finally {
        setIsLoading(false);
      }
    };

    loadHierarchyData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hierarchyData, entityConfig]);

  const handleNodeClick = (nodeData) => {
    setSelectedNode(nodeData);
    
    // If running in Power Apps context, open the record
    if (PowerPlatformHelpers.isPowerAppsContext() && nodeData.data) {
      PowerPlatformHelpers.openRecord(entityConfig.entityName, nodeData.id);
    }
  };

  const customNodeTemplate = (nodeData) => {
    if (customNodeRenderer) {
      return customNodeRenderer(nodeData);
    }
    
    return (
      <div className="dataverse-node" onClick={() => handleNodeClick(nodeData)}>
        <div className="node-header">
          <h4 className="node-name">{nodeData.name}</h4>
        </div>
        <div className="node-content">
          <p className="node-title">{nodeData.title}</p>
          {nodeData.data && nodeData.data.emailaddress1 && (
            <p className="node-email">{nodeData.data.emailaddress1}</p>
          )}
        </div>
        <div className="node-actions">
          <button 
            className="btn-view-record"
            onClick={(e) => {
              e.stopPropagation();
              handleNodeClick(nodeData);
            }}
            title="View Record"
          >
            👁️
          </button>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="dataverse-hierarchy-loading">
        <div className="loading-spinner"></div>
        <p>Loading hierarchy data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dataverse-hierarchy-error">
        <h3>Error Loading Hierarchy</h3>
        <p>{error}</p>
        <button onClick={() => window.location.reload()}>Retry</button>
      </div>
    );
  }

  if (!chartData) {
    return (
      <div className="dataverse-hierarchy-empty">
        <h3>No Hierarchy Data</h3>
        <p>No records found with the specified hierarchy configuration.</p>
      </div>
    );
  }

  return (
    <div className="dataverse-hierarchy-container">
      {showToolbar && (
        <div className="hierarchy-toolbar">
          <div className="toolbar-info">
            <h3>Organization Hierarchy</h3>
            <p>Entity: {entityConfig.entityName} | Records: {getRecordCount(chartData)}</p>
          </div>
          <div className="toolbar-actions">
            <button className="btn-refresh" onClick={() => window.location.reload()}>
              🔄 Refresh
            </button>
            <button className="btn-export" onClick={() => exportChart()}>
              📄 Export
            </button>
          </div>
        </div>
      )}
      
      <div className="hierarchy-chart">
        <OrganizationChart 
          datasource={chartData}
          NodeTemplate={customNodeTemplate}
          draggable={allowEdit}
          collapsible={true}
          multipleSelect={false}
          chartClass="dataverse-org-chart"
        />
      </div>
      
      {selectedNode && (
        <div className="selected-node-info">
          <h4>Selected: {selectedNode.name}</h4>
          <p>{selectedNode.title}</p>
          {selectedNode.data && (
            <div className="node-details">
              <p><strong>ID:</strong> {selectedNode.id}</p>
              {selectedNode.data.emailaddress1 && (
                <p><strong>Email:</strong> {selectedNode.data.emailaddress1}</p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Helper function to count records in hierarchy
const getRecordCount = (node) => {
  if (!node) return 0;
  let count = 1;
  if (node.children) {
    node.children.forEach(child => {
      count += getRecordCount(child);
    });
  }
  return count;
};

// Export functionality
const exportChart = () => {
  // This would integrate with the existing export functionality
  console.log("Exporting hierarchy chart...");
};

export default DataverseHierarchyChart;
