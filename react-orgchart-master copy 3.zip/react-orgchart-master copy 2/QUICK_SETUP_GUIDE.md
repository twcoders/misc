# 🚀 **Quick Setup Script for Hierarchy Configuration**

## 📋 **Step-by-Step Implementation**

### **Step 1: Identify Your Self-Referencing Setup**

**Common Self-Referencing Fields:**

| Entity | Lookup Field | Display Name |
|--------|-------------|--------------|
| Contact | `parentcustomerid` | Reports To |
| Account | `parentaccountid` | Parent Account |
| Custom Entity | `new_parent[entity]` | Parent [Entity] |

### **Step 2: Configure Web Resource Parameters**

#### **Method A: Direct HTML Configuration**

1. **Edit the Main HTML Web Resource**:
   - Go to: Solutions → Your Solution → `dsr_hierarchy_main_html`
   - Click "Edit" 

2. **Add Configuration Before `</head>` tag**:

```html
<script>
// 🎯 Replace this with your entity configuration
window.DataverseHierarchyConfig = {
  // 👇 CHANGE THESE VALUES FOR YOUR ENTITY
  entityName: "contact",                    // Your entity logical name
  selfReferencingField: "parentcustomerid", // Your lookup field
  
  // 👇 CUSTOMIZE CARD DISPLAY FIELDS
  cardFields: {
    title: "fullname",        // Main title on card
    subtitle: "jobtitle",     // Subtitle on card  
    info1: "department",      // First info line
    info2: "emailaddress1",   // Second info line
    info3: "telephone1",      // Third info line
    avatar: "entityimage"     // Profile image field (optional)
  },
  
  // 👇 HIERARCHY DISPLAY OPTIONS
  displayOptions: {
    direction: "vertical",    // "vertical" or "horizontal"
    autoExpand: 2,           // Auto-expand first 2 levels
    showActions: true,       // Show action buttons on cards
    showConnectors: true     // Show connecting lines
  },
  
  // 👇 CARD STYLING
  cardStyle: {
    width: 200,              // Card width in pixels
    height: 120,             // Card height in pixels
    backgroundColor: "#ffffff",
    borderColor: "#e1e1e1",
    textColor: "#323130"
  }
};
</script>
```

#### **Method B: Form Parameter Configuration**

**Add these parameters to your web resource on the form:**

```
?entity=contact&lookup=parentcustomerid&title=fullname&subtitle=jobtitle&info=department,emailaddress1,telephone1
```

**Parameter Guide:**
- `entity`: Your entity logical name
- `lookup`: Self-referencing lookup field
- `title`: Primary display field
- `subtitle`: Secondary display field  
- `info`: Comma-separated additional fields

### **Step 3: Add to Entity Form**

1. **Navigate to Your Entity Form**:
   ```
   Power Apps → Tables → [Your Entity] → Forms → Main Form
   ```

2. **Add New Tab or Section**:
   - Tab Name: "Organization Hierarchy" or "Company Structure"
   - Section Name: "Hierarchy View"

3. **Insert Web Resource**:
   - Component: Web Resource
   - Web Resource: `dsr_hierarchy_main_html`
   - Name: `HierarchyViewer`
   - Label: `Organizational Chart`

4. **Configure Dimensions**:
   ```
   Width: 100%
   Height: 600px (minimum recommended)
   Border: No
   Scrolling: Auto
   ```

5. **Add Parameters (if using Method B)**:
   ```
   Custom Parameter(s): entity=contact&lookup=parentcustomerid&title=fullname&subtitle=jobtitle&info=department,emailaddress1
   ```

### **Step 4: Test Your Configuration**

#### **Test Data Setup**

1. **Create Test Records with Hierarchy**:
   ```
   CEO (no parent)
   ├── VP Sales (reports to CEO)
   │   ├── Sales Manager 1 (reports to VP Sales)
   │   └── Sales Manager 2 (reports to VP Sales)
   └── VP Engineering (reports to CEO)
       ├── Dev Manager (reports to VP Engineering)
       └── QA Manager (reports to VP Engineering)
   ```

2. **Verify Lookup Relationships**:
   - Ensure parent-child relationships are set correctly
   - Check that lookup field contains proper references

#### **Testing Checklist**

- [ ] Hierarchy displays correctly
- [ ] Cards show expected information
- [ ] Parent-child relationships are correct
- [ ] Actions work (click to view, email, etc.)
- [ ] Performance is acceptable
- [ ] Mobile responsive (if needed)

### **Step 5: Customize Card Information**

#### **Basic Card Layout**

```javascript
// Standard 3-line card format
cardFields: {
  title: "fullname",           // Line 1: John Smith
  subtitle: "jobtitle",        // Line 2: Software Engineer  
  info1: "department",         // Line 3: Engineering
  info2: "emailaddress1",      // Line 4: john@company.com
  info3: "telephone1"          // Line 5: +1-555-0123
}
```

#### **Rich Card Layout**

```javascript
// Enhanced card with more details
cardFields: {
  title: "fullname",
  subtitle: "jobtitle", 
  info1: "department",
  info2: "emailaddress1",
  info3: "telephone1",
  info4: "address1_city",      // City
  info5: "managername",        // Manager name
  avatar: "entityimage",       // Profile picture
  status: "statuscode"         // Status indicator
}
```

### **Step 6: Advanced Customization**

#### **Custom Actions on Cards**

```javascript
cardActions: [
  {
    label: "View Profile",
    icon: "👤",
    action: "navigate",
    url: "/main.aspx?etn=contact&id={contactid}"
  },
  {
    label: "Send Email", 
    icon: "📧",
    action: "mailto",
    field: "emailaddress1"
  },
  {
    label: "Call",
    icon: "📞", 
    action: "tel",
    field: "telephone1"
  },
  {
    label: "Teams Chat",
    icon: "💬",
    action: "teams",
    field: "emailaddress1"
  }
]
```

#### **Conditional Field Display**

```javascript
// Show different fields based on job level
cardFields: {
  title: "fullname",
  subtitle: function(record) {
    return record.jobtitle || record.department || "Employee";
  },
  info1: function(record) {
    if (record.jobtitle && record.jobtitle.includes("Manager")) {
      return record.department + " (Manager)";
    }
    return record.department;
  }
}
```

## 🎯 **Entity-Specific Quick Configs**

### **Contact (Employee) Hierarchy**

```javascript
window.DataverseHierarchyConfig = {
  entityName: "contact",
  selfReferencingField: "parentcustomerid",
  cardFields: {
    title: "fullname",
    subtitle: "jobtitle", 
    info1: "department",
    info2: "emailaddress1",
    info3: "telephone1",
    avatar: "entityimage"
  }
};
```

### **Account (Company) Hierarchy**

```javascript
window.DataverseHierarchyConfig = {
  entityName: "account", 
  selfReferencingField: "parentaccountid",
  cardFields: {
    title: "name",
    subtitle: "accountnumber",
    info1: "telephone1", 
    info2: "websiteurl",
    info3: "address1_city",
    avatar: "entityimage"
  }
};
```

### **Custom Entity Template**

```javascript
window.DataverseHierarchyConfig = {
  entityName: "YOUR_ENTITY_NAME",           // e.g., "new_department"
  selfReferencingField: "YOUR_LOOKUP_FIELD", // e.g., "new_parentdepartment"
  cardFields: {
    title: "YOUR_NAME_FIELD",              // e.g., "new_name"
    subtitle: "YOUR_SECONDARY_FIELD",      // e.g., "new_manager"
    info1: "YOUR_INFO_FIELD_1",           // e.g., "new_location"
    info2: "YOUR_INFO_FIELD_2",           // e.g., "new_budget"
    info3: "YOUR_INFO_FIELD_3"            // e.g., "new_phone"
  }
};
```

## ✅ **Final Checklist**

- [ ] **Entity configured** with self-referencing lookup
- [ ] **Web resource updated** with configuration script
- [ ] **Form modified** with web resource component
- [ ] **Test data created** with hierarchy relationships
- [ ] **Security roles** grant appropriate access
- [ ] **Performance tested** with realistic data volume
- [ ] **Mobile compatibility** verified (if required)

## 🔧 **Troubleshooting**

**Issue: No hierarchy shows**
- Check entity name and lookup field name
- Verify data has proper parent-child relationships
- Ensure security access to entity and fields

**Issue: Cards show blank information**
- Verify field names exist in entity
- Check field security settings
- Confirm data exists in test records

**Issue: Performance problems**
- Limit auto-expand levels
- Reduce number of display fields
- Enable lazy loading for large hierarchies

Your hierarchy view is now ready to replace Microsoft's discontinued Hierarchy View feature! 🎉
