import React from "react";
import { BrowserRouter as Router, Route, NavLink } from "react-router-dom";
import Home from "./home/home";
import DefaultChart from "./default-chart/default-chart";
import PanZoomChart from "./pan-zoom-chart/pan-zoom-chart";
import CustomNodeChart from "./custom-node-chart/custom-node-chart";
import ExportChart from "./export-chart/export-chart";
import DragDropChart from "./drag-drop-chart/drag-drop-chart";
import EditChart from "./edit-chart/edit-chart";
import EditNode from "./edit-node/edit-node";
import DataverseHierarchyChart from "./dataverse-hierarchy/dataverse-hierarchy-chart";
import "./App.css";

const App = () => {
  return (
    <Router>
      <div className="wrapper">
        <nav>
          <NavLink to="/dataverse-hierarchy" activeClassName="selected">Dataverse Hierarchy</NavLink>
          <NavLink to="/custom-node-chart" activeClassName="selected">Custom Node Chart</NavLink>
        </nav>

     
        <Route path="/dataverse-hierarchy" component={DataverseHierarchyChart} />
        <Route path="/custom-node-chart" component={CustomNodeChart} />
      </div>
    </Router>
  );
};

export default App;
