import React from "react";
import OrganizationChart from "../components/ChartContainer";
import "./dataverse-hierarchy.css";

const DataverseHierarchyChart = () => {
  // Internal conversion function as fallback
  const convertLiveDataToOrgChart = (liveData) => {
    if (!liveData || liveData.length === 0) return null;
    
    // Map live data to chart nodes
    const nodes = liveData.map(record => ({
      id: record.new_positionid || record.new_departmentid || record.contactid || record.id,
      name: record.new_name || record.fullname || record.name || "Unknown",
      title: record.new_title || record.jobtitle || record.title || "",
      manager: record.new_manager || record.managerid_formatted || "N/A",
      level: record.new_level || record.new_positionlevel || "",
      salary: record.new_salary || "",
      department: record.new_department || record.departmentname || "",
      managerId: record._mdt_position2report_value || record.new_manager || record.managerid || record.parentid,
      children: []
    }));
    
    // Build hierarchy
    const nodeMap = {};
    nodes.forEach(node => nodeMap[node.id] = node);
    
    const rootNodes = [];
    nodes.forEach(node => {
      if (node.managerId && nodeMap[node.managerId]) {
        nodeMap[node.managerId].children.push(node);
      } else {
        rootNodes.push(node);
      }
    });
    
    // Return first root or virtual root
    if (rootNodes.length === 1) return rootNodes[0];
    if (rootNodes.length > 1) {
      return { id: "root", name: "Organization", title: "Root", children: rootNodes };
    }
    return null;
  };

  // Check for external conversion function first, fallback to internal logic
  let ds = null;
  
  // Try to use external conversion function from HTML page
  if (window.getConvertedHierarchyData && typeof window.getConvertedHierarchyData === 'function') {
    console.log('Using external conversion function from HTML page');
    ds = window.getConvertedHierarchyData();
  }
  
  // Fallback: check for live data with internal conversion
  if (!ds && window.DataverseHierarchyConfig && window.DataverseHierarchyConfig.liveData) {
    console.log('Using internal conversion function with live data:', window.DataverseHierarchyConfig.liveData.length, 'records');
    ds = convertLiveDataToOrgChart(window.DataverseHierarchyConfig.liveData);
  }
  
  // Fallback to sample data if no live data
  if (!ds) {
    console.log('Using sample data');
    ds = {
      id: "user1",
      name: "John Smith",
      title: "Chief Executive Officer",
      manager: "Board of Directors",
      level: "Executive",
      salary: "250000",
      department: "Executive",
      children: [
        {
          id: "user2",
          name: "Sarah Johnson", 
          title: "Vice President of Sales",
          manager: "John Smith",
          level: "VP",
          salary: "150000",
          department: "Sales",
          children: [
            {
              id: "user4",
              name: "Jennifer Wilson",
              title: "Sales Manager",
              manager: "Sarah Johnson",
              level: "Manager",
              salary: "95000",
              department: "Sales",
              children: [
                {
                  id: "user7",
                  name: "David Lee",
                  title: "Sales Representative",
                  manager: "Jennifer Wilson",
                  level: "Individual Contributor",
                  salary: "65000",
                  department: "Sales"
                }
              ]
            }
          ]
        },
        {
          id: "user3",
          name: "Mike Davis",
          title: "Vice President of Engineering",
          manager: "John Smith",
          level: "VP",
          salary: "160000",
          department: "Engineering",
          children: [
            {
              id: "user5", 
              name: "Robert Brown",
              title: "Engineering Manager",
              manager: "Mike Davis",
              level: "Manager",
              salary: "120000",
              department: "Engineering",
              children: [
                {
                  id: "user6",
                  name: "Lisa Garcia", 
                  title: "Software Engineer",
                  manager: "Robert Brown",
                  level: "Senior",
                  salary: "85000",
                  department: "Engineering"
                }
              ]
            }
          ]
        }
      ]
    };
  }

  //return <OrganizationChart datasource={ds} />;
  return <OrganizationChart datasource={ds} pan={true} zoom={true} />;
};

export default DataverseHierarchyChart;
